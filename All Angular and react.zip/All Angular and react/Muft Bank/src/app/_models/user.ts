export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    aadhar:string;
    mobile:string;
    email:string;
    accountnumber:number;
    ifsc:string;
    branch:string;
}