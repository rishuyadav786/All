export class Customer {
    id:number;
    custName:string;
    custEmail:string;
    custMob:number;
    custPass:string;
    custAddhar:number;
}
