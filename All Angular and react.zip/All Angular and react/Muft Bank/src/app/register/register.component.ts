import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { AlertService, UserService } from '../_services/index';
// var email   = require('emailjs/email');
import{email} from 'emailjs/email'
@Component({
    templateUrl: 'register.component.html'
})

export class RegisterComponent {
    model: any = {};
    loading = false;

    constructor(
        private router: Router,
        private userService: UserService,
        private alertService: AlertService) { }





        // var server  = email.server.connect({
        //     user:    "senderemail", 
        //     password:"senderpassword", 
        //     host:    "<email server url>", 
        //     ssl:     true
        //  });
          
        //  // send the message and get a callback with an error or details of the message that was sent
        //  server.send({
        //     text:    "You have signed up", 
        //     from:    "sender email", 
        //     to:      req.body.name,
        //     subject: "Welcome to my app",
        //     attachment: 
        //     [
        //        {data:"<html>i <i>hope</i> this works!</html>", alternative:true},
        //        {path:"pathtofile.zip", type:"application/zip", name:"renamed.zip"}
        //     ]
        //  }, function(err, message) { 
        //      if(err)
        //      console.log(err);
        //      else
        //      res.json({success: true, msg: 'sent'});
        //   });
                 
        //      }





    register() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success('Registration successful', true);
                    this.router.navigate(['/login']);
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                });
    }
}
