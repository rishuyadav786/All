import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BodyComponent } from './body/body.component';
import { FooterComponent } from './footer/footer.component';
import { AppRoutingModule } from './/app-routing.module';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {RouterModule, Routes} from "@angular/router";

import { FormsModule} from "@angular/forms";
import { ContactComponent } from './contact/contact.component';
import { ServiceComponent } from './service/service.component';
import { AboutComponent } from './about/about.component';
// import { HomeComponent } from './home/home.component';
// import { LoginComponent } from './login/login.component';
// import { RegisterComponent } from './register/register.component';
import { HttpModule } from '@angular/http';
import { FilterPipe } from './filter.pipe';




import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers/index';


import { routing }        from './app.routing';

import { AlertComponent } from './_directives/index';
import { AuthGuard } from './_guards/index';
import { JwtInterceptor } from './_helpers/index';
import { AlertService, AuthenticationService, UserService } from './_services/index';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';

const routes:Routes = [
  {path: "", redirectTo: "home", pathMatch: "full"},
  {path: "contact", component: ContactComponent},
  {path: "about", component: AboutComponent},
  {path: "service", component: ServiceComponent},
  {path: "login", component: LoginComponent},
  {path: "register", component: RegisterComponent}
  
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BodyComponent,
    FooterComponent,
    ContactComponent,
    ServiceComponent,
    AboutComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    FilterPipe,
    
    AlertComponent,
  
    // routing
  ],
  providers: [
    AuthGuard,
    AlertService,
    AuthenticationService,
    UserService,
    {
        provide: HTTP_INTERCEPTORS,
        useClass: JwtInterceptor,
        multi: true
    },

    // provider used to create fake backend
    fakeBackendProvider
],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule,
    RouterModule.forRoot(routes), 
   
    HttpClientModule,HttpModule,
    routing

  ],

  exports: [  RouterModule  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { }




