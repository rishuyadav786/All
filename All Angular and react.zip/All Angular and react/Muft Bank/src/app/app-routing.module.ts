import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BodyComponent } from './body/body.component';
import { FooterComponent } from './footer/footer.component';


import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { FormsModule} from "@angular/forms";
import { ContactComponent } from './contact/contact.component';
import { ServiceComponent } from './service/service.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';



const routes:Routes = [
  {path: "", redirectTo: "home", pathMatch: "full"},
  {path: "contact", component: ContactComponent},
  {path: "about", component: AboutComponent},
  {path: "service", component: ServiceComponent},
  
];




@NgModule({
imports: [ CommonModule, RouterModule.forRoot(routes)  ],
exports: [  RouterModule  ],
declarations: []
})

export class AppRoutingModule {

}
 