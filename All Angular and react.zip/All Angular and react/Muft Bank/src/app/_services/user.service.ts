import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { User } from '../_models/index';
import { Investor } from '../investor';

import { Observable } from 'rxjs/Observable';
import { Http, Response } from "@angular/http";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";

import { HttpModule } from '@angular/http';
import { Customer } from '../customer';
@Injectable()
export class UserService {
    customers:Customer[]=[];
    constructor(private http: HttpClient,private http1: Http) { }

    getAll() {
        return this.http.get<User[]>('/api/users');
    }
    getAll2() :Observable<User[]>{
        console.log("hiiiiiiii");
        return this.http1.get('assets/customer.json/').map((response: Response) => <User[]>response.json());
    }

    getById(id: number) {
        return this.http.get('/api/users/' + id);
    }

    create(user: User) {
        return this.http.post('/api/users', user);
    }
    
    create1(user: User) {
        return this.http1.post('assets/customer.json/',user).map((response: Response) => <User[]>response.json());
    }

    update(user: User) {
        return this.http.put('/api/users/' + user.id, user);
    }

    delete(id: number) {
        return this.http.delete('/api/users/' + id);
    }
    getAll1(): Observable<User[]> {
        return this.http1.get("http://localhost:3000/customer").map((response: Response) => <User[]>response.json());
    
      }
      getAll3(): Observable<Investor[]> {
        return this.http1.get("http://localhost:3000/investor").map((response: Response) => <Investor[]>response.json());
    
      }

      handleError(error: Response) {
        console.log(error);
        return Observable.throw(error);
      }
}