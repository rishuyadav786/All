export class Investor {
    id:number;
    invName:string;
    invEmail:string;
    invPercentage:number;
    invCompany:string;
}
