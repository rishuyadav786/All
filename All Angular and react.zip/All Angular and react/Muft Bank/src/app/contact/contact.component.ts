import { Component, OnInit } from '@angular/core';


import { User } from '../_models/index';

import { Investor } from '../investor';
import { UserService } from '../_services/index';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
    currentUser: User;
    users: User[] = [];
        investors:Investor[]=[];
    constructor(private userService: UserService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }

    ngOnInit() {
        this.loadAllUsers();
    }

    deleteUser(id: number) {
        this.userService.delete(id).subscribe(() => { this.loadAllUsers() });
    }

    private loadAllUsers() {
        this.userService.getAll3().subscribe(investor => { this.investors= investor; });
    }
}