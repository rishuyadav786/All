import React, { Component } from 'react';

class ShowProduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    delete(id) {
        this.setState({
            abc: this.props.pobject.splice(id, 1)
        });
    }

//creating show customer visit information...
    render() {
        const myListData = (<div className="text-left">
            {this.props.pobject.map((data, key) =>
                <p key={data.custId} >
                {/* Name : {data.custId} */}
                <br/>
               Comments : {data.addr}
                <br/>
                {/* Email ID : {data.custName}
                <br/>
                Mobile Number : {data.custMobile}
                <br/>
               
                Description/Purpose: {data.description}
                <br />
                Date of Visit : {data.date}
                <br/> */}
                    {<button onClick={this.delete.bind(this, key)}>
                        Delete
    </button>}  </p>
            )}</div>);

        return (
            <div>
              
                {myListData}
                </div>
        );
    }
}
    export default ShowProduct;