import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './home';
import Profile from './profile';


class Body extends Component {
  render() {
    return (
      <div className="container">
        <div className="col-md-3">
          <Profile />
         
        </div>
        <div className="col-md-6 col-md-offset-1">

          <Home /><br />
          <Home /><br />
          <Home /><br />
          <Home />
        </div>
      </div>
    );
  }
}


export default Body;
