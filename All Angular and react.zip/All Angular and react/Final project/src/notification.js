import React, { Component } from 'react';
import logo from './logo.svg';




class Notification extends Component {
 
  render() {
    return (
      
    <div>Notification work
        </div>
     
    );
  }
}


export default Notification;
