import React, { Component } from 'react';
import logo from './logo.svg';
import './style.css';



class Profile extends Component {
 
  render() {
    return (
   
<div class="container">
	<div class="row">
		<div class="col-lg-3 col-sm-6">
     
            <div class="card hovercard">
                <div class="cardheader">

                </div>
                <div class="avatar">
                    <img alt="" src="./back.jpg"/>
                </div>
                <div class="info">
                    <div class="title">
                        <a target="_blank" href="https://scripteden.com/"> Rishu Yadav</a>
                    </div>
                    <div class="desc"> Capgemi whiteField iGate</div>
                    <div class="desc">yadavrishu98@gmail.com</div>
                   
                    <div class="desc"> <b>Mobile : </b>9804050418</div>
                </div>
                <div class="bottom">
                    <a class="btn1 btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="btn1 btn-danger btn-sm" rel="publisher"
                       href="https://plus.google.com/111385568856033331727">
                        <i class="fa fa-google-plus"></i>
                    </a>
                    <a class="btn1 btn-primary btn-sm" rel="publisher"
                       href="https://www.facebook.com/rishuyadav786">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="btn1 btn-danger btn-sm" rel="publisher" href="https://www.instagram.com/rishuyadav204/">
                        <i class="fa fa-instagram"></i>
                    </a>
                </div>
            </div>

        </div>

	</div>
</div>
    );
  }
}


export default Profile;

