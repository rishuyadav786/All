import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './header';
import Body from './body';
class App extends Component {
  render() {
    return (
      // <div className="App">
      <div >
        <Header />

        {/* <Body/> */}
        <Footer />

      </div>
    );
  }
}

class Header1 extends Component {
  render() {
    return (
      <div>
        This is  inner header

      </div>
    );
  }
}
// class Body extends Component {
//   render() {
//     return (
//       <div>
//      This is Body
//       </div>
//     );
//   }
// }
class Footer extends Component {
  render() {
    return (
      <div>
        This is footer
      </div>
    );
  }
}

export default App;
