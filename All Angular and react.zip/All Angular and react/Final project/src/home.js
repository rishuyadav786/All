import React, { Component } from 'react';
import logo from './logo.svg';


import './App.css';
import Addproduct from './addproducts';
import ShowProduct from './showproducts';

class App extends Component {
  constructor(){
  super();
  this.state={
    custData:[]
  }
  }
  //code for adding the product...
  addProduct(data){
    let olddata=this.state.custData
    olddata.push(data)
    this.setState({
      custData:olddata
    })
  }
  //code for deleting or repalcing the product...
  replaceProduct(data,id)
  { 
    let olddata=this.state.custData
    olddata.splice(id,1,data)
    this.setState({
      custData:olddata
    })    
  }
 
  
  render() {

    return (
      <div className="App">    
          <ShowProduct  pobject={this.state.custData} pobject1={this.replaceProduct.bind(this)}/>   
      <Addproduct getData={this.addProduct.bind(this)}/> 
  
      </div>
    );
  }
}




class Home extends Component {

  state = {
    count: 0
  };
  handleClick = () => {
    this.setState(({ count }) => ({
      count: count + 1
    }));
  };
   Prducts=[{id:1,name:"Rishu",location:"kolkata"},
   {id:2,name:"yash",location:"Banglore"},
   {id:3,name:"Rishab",location:"Mumabai"}];
 
  render() {
    return (
      
      <div className="row">
      <div className="data">
     
      <span><img src={logo} height="50px;"/><u>Rishu Yadav</u>
          <br/>capgemini whitefield </span>

          <p>Software engineer at capgemini..he loves codeing...he loves codeing...he loves codeing..
            .he loves codeing...he loves codeing...he loves codeing...he loves codeing...</p><hr/>
            <img src={logo} height="250px;"></img>
          
            
           <hr/>
           {/* {this.Prducts[1].name}  */}
           
            <span>Like &nbsp;
                 {this.state.count}</span> &nbsp; &nbsp;<span>Comments {0}</span><br></br>
                 <hr/><App/>
                 <hr/>
           
            {/* <textarea rows="3"  cols="60" placeholder="comments..." className="form-control"></textarea><br/> */}
          
            <span class="glyphicon glyphicon-plus"></span>   <button class="glyphicon glyphicon-heart" onClick={this.handleClick}></button> <span class="glyphicon glyphicon-star"></span>  <span class="glyphicon glyphicon-envelop"></span>
            <span class="glyphicon glyphicon-share-alt"></span></div>
      </div> 
     
    );
  }
}


export default Home;
